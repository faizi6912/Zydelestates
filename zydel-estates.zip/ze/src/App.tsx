import { useEffect, useState } from 'react'
import { Menu, X, MessageCircle, ChevronDown, Banknote, Eye, Clock, Handshake, FileText, Sparkles, Zap, Users, Phone, Mail, MapPin, Instagram, Facebook } from 'lucide-react'
import LeadForm from './components/LeadForm'
import { site, waLink, Intent } from './config/site'

type FormIntent = 'sell' | 'buy'
const links = [['#how', 'How It Works'], ['#why', 'Why Zydel'], ['#faq', 'FAQs'], ['#contact', 'Contact']]
const problems = [
  [Banknote, 'Upfront marketing costs', 'Professional videos and social media marketing can get expensive, and many owners hesitate to pay before seeing any outcome.'],
  [Eye, 'Limited property visibility', 'A good property can still go unnoticed without consistent, well-presented content.'],
  [Clock, 'Too much time and effort', 'Content, promotion, inquiries and follow-ups take time that most owners do not have.'],
  [Users, 'Finding the right connection', 'Buyers can struggle to reach relevant opportunities, especially when expectations are unclear.'],
] as const
const values = [
  [FileText, 'Transparent terms', 'We explain the collaboration terms before any work begins.'],
  [Sparkles, 'Creative presentation', 'Posts and videos that show a property clearly and attractively.'],
  [Zap, 'Convenient process', 'We coordinate the agreed marketing work so you do not have to.'],
  [Handshake, 'Client-focused communication', 'Clear updates and personal assistance from our team.'],
] as const
const sellSteps = [
  ['Tell us about your property', 'Submit your name, contact details, property location, property type and a few basic details.'],
  ['We discuss the details', 'Our team contacts you to understand the property and whether it suits our services.'],
  ['Agree on the terms', 'We discuss the marketing approach, commission arrangements and responsibilities before starting.'],
  ['We market the property', 'We create or coordinate agreed content such as posts and videos. Interested parties are handled through the agreed communication process.'],
]
const buySteps = [
  ['Share your requirements', 'Tell us your preferred location, property type and budget.'],
  ['Discuss your preferences', 'Our team talks through what matters to you.'],
  ['Connect with relevant opportunities', 'We help you reach relevant contacts and opportunities.'],
  ['Continue with the agreed process', 'You proceed through the property process agreed with the relevant parties.'],
]
const faqs = [
  ['Do I have to pay upfront to market my property?', 'For eligible property marketing collaborations, Zydel Estates works on an agreed commission-based model without an upfront marketing fee. Eligibility and terms are discussed before work begins.'],
  ['How does your commission-based model work?', 'We discuss the responsibilities, applicable commission, and payment terms with you before beginning the collaboration. The agreed terms should be documented clearly.'],
  ['Do you help people who want to buy property?', 'Yes. You can submit your property requirements, including your preferred location, budget, and property type. Our team will review your inquiry and discuss possible next steps.'],
  ['Which areas do you cover?', 'Our initial focus is Lahore and surrounding areas. You can submit inquiries from other locations as well, and our team will confirm whether assistance is available.'],
  ['What information do I need to provide?', 'We generally need your name, contact information, property location, property type, and basic details about your requirements.'],
  ['Do you guarantee that my property will sell?', 'No. Property sales depend on many factors, including pricing, market conditions, demand, and the property’s suitability. We help with the agreed marketing activities but cannot guarantee a sale.'],
  ['Do I need professional photos or videos?', 'Tell us what material you already have. We will discuss the available marketing approach and whether additional content creation is required.'],
  ['How do I get started?', 'Submit the relevant form on our website or contact us through WhatsApp. Our team will review your inquiry and get in touch.'],
  ['Do I need to sign an agreement?', 'Applicable collaboration terms should be discussed and documented before marketing begins.'],
  ['Is submitting an inquiry free?', 'Submitting an inquiry through our website is free. Any applicable commission or other agreed costs will be discussed transparently before a collaboration begins.'],
]

function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll('.reveal')
    if (!('IntersectionObserver' in window)) { els.forEach(e => e.classList.add('in')); return }
    const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target) } }), { threshold: 0.1 })
    els.forEach(e => io.observe(e)); return () => io.disconnect()
  }, [])
}
const Sec = ({ id, alt, children }: { id?: string; alt?: boolean; children: React.ReactNode }) =>
  <section id={id} className={`scroll-mt-16 ${alt ? 'bg-bg2' : ''}`}><div className="reveal mx-auto max-w-6xl px-5 py-16 md:py-24">{children}</div></section>
const H = ({ label, children, lead }: { label?: string; children: React.ReactNode; lead?: string }) =>
  <div className="mb-10 max-w-2xl">{label && <p className="mb-3 flex items-center gap-3 text-sm text-gold"><span className="h-px w-8 bg-gold" />{label}</p>}
    <h2 className="text-3xl leading-tight md:text-4xl">{children}</h2>{lead && <p className="mt-4 text-lg text-mute">{lead}</p>}</div>
const WA = ({ i = 'general', cls = 'btn btn-line', text = 'Talk to us on WhatsApp' }: { i?: Intent; cls?: string; text?: string }) => {
  const u = waLink(i); return u ? <a href={u} target="_blank" rel="noreferrer" className={cls}><MessageCircle size={18} />{text}</a> : null }

export default function App() {
  const [intent, setIntent] = useState<FormIntent>('sell')
  const [menu, setMenu] = useState(false)
  const [tab, setTab] = useState<FormIntent>('sell')
  useReveal()
  const go = (i: FormIntent) => { setIntent(i); setMenu(false); document.getElementById('inquiry')?.scrollIntoView({ behavior: 'smooth' }) }
  const steps = tab === 'sell' ? sellSteps : buySteps
  const wa = waLink(intent)
  return (<>
    <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:bg-gold focus:p-3 focus:text-bg">Skip to content</a>
    <header className="sticky top-0 z-40 border-b border-line bg-bg/95 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
        <a href="#top" className="font-display text-xl tracking-wide md:text-2xl">Zydel <span className="text-gold">Estates</span></a>
        <nav aria-label="Main" className="hidden items-center gap-7 text-sm lg:flex">
          {links.map(([h, l]) => <a key={h} href={h} className="text-mute hover:text-gold">{l}</a>)}</nav>
        <div className="hidden items-center gap-3 lg:flex">
          <button onClick={() => go('sell')} className="btn btn-gold !py-2">Sell Your Property</button>
          <button onClick={() => go('buy')} className="btn btn-line !py-2">Buy a Property</button></div>
        <button className="p-2 lg:hidden" aria-label={menu ? 'Close menu' : 'Open menu'} aria-expanded={menu} onClick={() => setMenu(!menu)}>{menu ? <X /> : <Menu />}</button>
      </div>
      <div className={`grid overflow-hidden border-line bg-bg2 transition-all duration-300 lg:hidden ${menu ? 'max-h-96 border-t' : 'max-h-0'}`}>
        <nav aria-label="Mobile" className="grid gap-1 px-5 py-4">
          {links.map(([h, l]) => <a key={h} href={h} onClick={() => setMenu(false)} className="py-2 text-mute">{l}</a>)}
          <button onClick={() => go('sell')} className="btn btn-gold mt-2">Sell Your Property</button>
          <button onClick={() => go('buy')} className="btn btn-line">Buy a Property</button></nav></div>
    </header>

    <main id="main"><div id="top" />
      <section className="relative overflow-hidden">
        <svg aria-hidden="true" className="pointer-events-none absolute -right-24 top-0 hidden h-full w-[55%] opacity-70 md:block" viewBox="0 0 600 700" fill="none" stroke="#C6A76A" strokeWidth="1">
          <path d="M60 640h520M120 640V300l180-120 180 120v340M210 640V380h180v260M300 180V60M120 300h360M255 440h90M300 380v260" opacity=".5" /><path d="M20 560h200M380 560h200" opacity=".25" /></svg>
        <div className="relative mx-auto max-w-6xl px-5 py-20 md:py-32">
          <h1 className="max-w-3xl text-4xl leading-[1.1] md:text-6xl">Your property journey, <span className="text-gold">without the upfront marketing cost.</span></h1>
          <p className="mt-6 max-w-xl text-lg text-mute">Whether you’re looking to sell your property or find your next home, Zydel Estates helps connect the right people through creative property marketing and a straightforward process.</p>
          <p className="mt-5 max-w-xl border-l-2 border-gold pl-4 text-ivory">{site.commissionWording}</p>
          <div className="mt-9 flex flex-wrap gap-4">
            <button onClick={() => go('sell')} className="btn btn-gold">Sell My Property</button>
            <button onClick={() => go('buy')} className="btn btn-line">Help Me Find a Property</button></div>
          <div className="mt-5"><WA cls="inline-flex items-center gap-2 text-sm text-gold underline underline-offset-4 hover:text-gold2" /></div>
          <p className="mt-8 text-sm text-mute">No complicated process. Clear terms. Personal assistance.</p>
        </div></section>

      <Sec alt><H label="The problem">Property decisions are big enough. Marketing shouldn’t make them harder.</H>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{problems.map(([I, t, d]) =>
          <div key={t} className="border border-line bg-card p-6 transition-colors hover:border-gold"><I className="text-gold" size={26} /><h3 className="mt-4 text-xl">{t}</h3><p className="mt-2 text-sm text-mute">{d}</p></div>)}</div></Sec>

      <Sec><H label="Our solution" lead="We showcase properties with creative posts and videos, use suitable digital channels for visibility, coordinate the agreed marketing, and help connect interested people with relevant contacts.">Less hassle. A smarter way to get started.</H>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{values.map(([I, t, d]) =>
          <div key={t} className="border border-line p-6 transition-transform hover:-translate-y-1"><I className="text-gold" size={26} /><h3 className="mt-4 text-xl">{t}</h3><p className="mt-2 text-sm text-mute">{d}</p></div>)}</div>
        <p className="mt-8 max-w-3xl text-sm text-mute">{site.commissionWording} Clients still provide accurate property information, relevant documents when requested, and reasonable cooperation during the process. We cannot guarantee a sale, a buyer, or a timeline.</p></Sec>

      <Sec id="how" alt><H label="How it works">Four clear steps.</H>
        <div role="tablist" aria-label="Process" className="mb-10 inline-flex border border-line">
          {(['sell', 'buy'] as FormIntent[]).map(t => <button key={t} role="tab" aria-selected={tab === t} onClick={() => setTab(t)} className={`min-h-[44px] px-5 text-sm font-semibold ${tab === t ? 'bg-gold text-bg' : 'text-mute'}`}>{t === 'sell' ? 'For sellers' : 'For buyers'}</button>)}</div>
        <ol className="grid gap-0 md:grid-cols-4 md:gap-6">{steps.map(([t, d], i) =>
          <li key={t} className="relative border-l border-gold pb-8 pl-6 md:border-l-0 md:border-t md:pb-0 md:pl-0 md:pt-6">
            <span className="absolute -left-[7px] top-0 h-3 w-3 bg-gold md:-top-[7px] md:left-0" /><p className="text-sm text-gold">Step {i + 1}</p><h3 className="mt-1 text-xl">{t}</h3><p className="mt-2 text-sm text-mute">{d}</p></li>)}</ol>
        <p className="mt-8 text-sm text-mute">Submitting a form is an inquiry, not a confirmed property booking or a guarantee that a suitable property is available.</p></Sec>

      <Sec><H label="Our approach" lead="Illustrative samples of the kinds of content we create. These are design mockups, not completed client projects.">How we present properties</H>
        <div className="grid gap-5 md:grid-cols-3">
          {[['Property showcase posts', 'Instagram and Facebook', 'aspect-[4/5]'], ['Short-form property videos', 'Vertical 9:16, TikTok-compatible', 'aspect-[9/16] max-h-[420px]'], ['Promotional creatives', 'Facebook and Instagram', 'aspect-square']].map(([t, s, a]) =>
            <figure key={t} className="border border-line bg-card p-5"><div role="img" aria-label={`Illustrative placeholder for ${t}`} className={`${a} mx-auto flex w-full items-end border border-line bg-gradient-to-b from-bg2 to-bg p-4`}>
              <div><div className="mb-2 h-px w-10 bg-gold" /><p className="font-display text-lg">Sample layout</p><p className="text-xs text-mute">Replace with your own imagery</p></div></div>
              <figcaption className="mt-4"><h3 className="text-lg">{t}</h3><p className="text-sm text-mute">{s}</p></figcaption></figure>)}</div></Sec>

      <Sec alt><div className="grid gap-6 md:grid-cols-2">
        <div className="border border-line bg-card p-8"><h2 className="text-3xl">Thinking about selling?</h2><p className="mt-3 text-mute">Tell us about your property. We’ll discuss how Zydel Estates may help present and market it to relevant audiences.</p><button onClick={() => go('sell')} className="btn btn-gold mt-6">Submit My Property</button></div>
        <div className="border border-line bg-card p-8"><h2 className="text-3xl">Looking for your next property?</h2><p className="mt-3 text-mute">Share your preferred location, property type, and budget so our team can understand your requirements and discuss suitable next steps.</p><button onClick={() => go('buy')} className="btn btn-line mt-6">Share My Requirements</button></div></div></Sec>

      <Sec id="why"><H label="Why Zydel Estates">A clearer way to market a property.</H>
        <ul className="grid gap-4 md:grid-cols-2">{['No upfront marketing fee for eligible commission-based collaborations.', 'Creative property presentation.', 'Clear discussion of terms before work begins.', 'Convenient communication.', 'A process tailored to the property and the client’s needs.'].map(b =>
          <li key={b} className="border-l-2 border-gold py-1 pl-4 text-lg">{b}</li>)}</ul></Sec>

      <Sec id="faq" alt><H label="FAQs">Questions we hear most.</H>
        <div className="max-w-3xl divide-y divide-line border-y border-line">{faqs.map(([q, a]) =>
          <details key={q} className="group py-5"><summary className="flex min-h-[44px] cursor-pointer list-none items-center justify-between gap-4 font-medium">{q}<ChevronDown size={18} className="shrink-0 text-gold transition-transform duration-300 group-open:rotate-180" /></summary><p className="pb-1 text-mute">{a}</p></details>)}</div></Sec>

      <Sec id="inquiry"><div className="grid gap-10 lg:grid-cols-[1fr_1.4fr]">
        <div><H label="Get started" lead="Tell us what you need. Our team will review your inquiry and get in touch.">Submit your inquiry.</H>
          <WA i={intent} cls="btn btn-line" text="Prefer WhatsApp?" /></div>
        <LeadForm intent={intent} setIntent={setIntent} /></div></Sec>

      <Sec id="contact" alt><div className="text-center"><h2 className="text-3xl md:text-5xl">Your next property step starts here.</h2>
        <p className="mx-auto mt-4 max-w-xl text-lg text-mute">Whether you’re selling a property or looking for one, tell us what you need and let us discuss how we can help.</p>
        <div className="mt-8 flex flex-wrap justify-center gap-4"><button onClick={() => go('sell')} className="btn btn-gold">Sell My Property</button><button onClick={() => go('buy')} className="btn btn-line">Find a Property</button><WA i="general" text="Contact Us on WhatsApp" /></div></div></Sec>

      <Sec id="privacy"><H label="Privacy notice">How we use your information</H>
        <p className="max-w-3xl text-mute">The details you submit through our inquiry form are used to respond to your inquiry and to discuss possible next steps with you. We ask only for information we need. Please do not send ID numbers or financial account details through the form. [Replace this notice with your full privacy policy, including how long you keep data and how to request deletion, before launch.]</p></Sec>
    </main>

    <footer className="border-t border-line bg-bg2">
      <div className="mx-auto grid max-w-6xl gap-8 px-5 py-12 md:grid-cols-3">
        <div><p className="font-display text-2xl">Zydel <span className="text-gold">Estates</span></p><p className="mt-2 text-sm text-mute">Property marketing and assistance. {site.serviceAreas}.</p></div>
        <ul className="grid gap-1 text-sm text-mute">{[...links, ['#privacy', 'Privacy Policy']].map(([h, l]) => <li key={h}><a className="hover:text-gold" href={h}>{l}</a></li>)}</ul>
        <ul className="grid gap-2 text-sm text-mute">
          {wa && <li><a className="flex gap-2 hover:text-gold" href={wa} target="_blank" rel="noreferrer"><MessageCircle size={16} />WhatsApp</a></li>}
          {site.phone && <li className="flex gap-2"><Phone size={16} />{site.phone}</li>}
          {site.email && <li className="flex gap-2"><Mail size={16} />{site.email}</li>}
          {site.address && <li className="flex gap-2"><MapPin size={16} />{site.address}</li>}
          {site.instagram && <li><a className="flex gap-2 hover:text-gold" href={site.instagram} target="_blank" rel="noreferrer"><Instagram size={16} />Instagram</a></li>}
          {site.facebook && <li><a className="flex gap-2 hover:text-gold" href={site.facebook} target="_blank" rel="noreferrer"><Facebook size={16} />Facebook</a></li>}
          {!wa && !site.phone && !site.email && !site.address && !site.instagram && !site.facebook && <li>Add your contact details in src/config/site.ts</li>}</ul></div>
      <p className="border-t border-line py-5 text-center text-xs text-mute">© {new Date().getFullYear()} Zydel Estates. All rights reserved.</p>
    </footer>
    {wa && <a href={wa} target="_blank" rel="noreferrer" aria-label="Chat with Zydel Estates on WhatsApp" className="fixed bottom-5 right-5 z-30 flex h-14 w-14 items-center justify-center bg-gold text-bg shadow-lg hover:bg-gold2"><MessageCircle /></a>}
  </>)
}
