// EDIT THIS FILE: contact details, wording and service areas live here. Leave '' to hide an item.
export const site = {
  name: 'Zydel Estates',
  whatsapp: '',   // digits only with country code, e.g. '923001234567'
  phone: '',      // e.g. '+92 300 1234567'
  email: '',
  instagram: '',  // full URL
  facebook: '',   // full URL
  address: '',
  serviceAreas: 'Lahore and surrounding areas',
  commissionWording: 'Eligible property marketing collaborations are commission-based, with no upfront marketing fee under agreed terms.',
}
export type Intent = 'sell' | 'buy' | 'general'
const msgs: Record<Intent, string> = {
  general: 'Hi Zydel Estates, I would like assistance with a property.',
  sell: 'Hi Zydel Estates, I want to discuss marketing my property.',
  buy: 'Hi Zydel Estates, I am looking for a property and would like assistance.',
}
/** Returns '' when no WhatsApp number is set, so callers hide the button instead of rendering a broken link. */
export const waLink = (i: Intent = 'general') =>
  site.whatsapp ? `https://wa.me/${site.whatsapp.replace(/\D/g, '')}?text=${encodeURIComponent(msgs[i])}` : ''
