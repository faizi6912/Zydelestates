import { FormEvent, useState } from 'react'
import { Loader2, CheckCircle2 } from 'lucide-react'
type Intent = 'sell' | 'buy'
const types = ['House', 'Apartment', 'Plot', 'Commercial Property', 'Other']
const purposes = ['Residential', 'Commercial', 'Investment', 'Other']
const methods = ['Phone call', 'WhatsApp', 'Email']
export default function LeadForm({ intent, setIntent }: { intent: Intent; setIntent: (i: Intent) => void }) {
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle')
  const [err, setErr] = useState<Record<string, string>>({})
  const sell = intent === 'sell'
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const form = e.currentTarget
    const d = new FormData(form)
    const v = (k: string) => String(d.get(k) ?? '').trim()
    const x: Record<string, string> = {}
    if (!v('fullName')) x.fullName = 'Enter your full name.'
    if (!/^\+?[\d\s()-]{7,}$/.test(v('phone'))) x.phone = 'Enter a valid phone number, for example 0300 1234567.'
    if (v('whatsapp') && !/^\+?[\d\s()-]{7,}$/.test(v('whatsapp'))) x.whatsapp = 'Enter a valid WhatsApp number or leave it blank.'
    if (v('email') && !/^\S+@\S+\.\S+$/.test(v('email'))) x.email = 'Enter a valid email address or leave it blank.'
    if (!v('location')) x.location = sell ? 'Enter the property location or area.' : 'Enter your preferred location or area.'
    if (!d.get('consent')) x.consent = 'Please agree to be contacted to submit your inquiry.'
    setErr(x)
    if (Object.keys(x).length) { document.getElementById(Object.keys(x)[0])?.focus(); return }
    setStatus('loading')
    try {
      const body = new URLSearchParams()
      body.append('form-name', 'property-inquiry'); body.append('intent', intent)
      d.forEach((val, k) => { if (k !== 'form-name') body.append(k, String(val)) })
      const r = await fetch('/', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: body.toString() })
      if (!r.ok) throw new Error(String(r.status))
      setStatus('success'); form.reset()
    } catch { setStatus('error') }
  }
  if (status === 'success') return (
    <div role="status" className="border border-gold bg-card p-8 text-center">
      <CheckCircle2 className="mx-auto text-gold" size={36} />
      <h3 className="mt-4 text-2xl">Inquiry received</h3>
      <p className="mt-2 text-mute">Thank you. Our team will review your inquiry and get in touch. This is an inquiry, not a confirmed booking or a guarantee that a suitable property is available.</p>
      <button className="btn btn-line mt-6" onClick={() => setStatus('idle')}>Send another inquiry</button>
    </div>)
  const Fld = ({ id, label, children }: { id: string; label: string; children: React.ReactNode }) => (
    <div><label htmlFor={id} className="mb-1 block text-sm font-medium">{label}</label>{children}
      {err[id] && <p id={`${id}-err`} role="alert" className="mt-1 text-sm text-red-400">{err[id]}</p>}</div>)
  const p = (id: string) => ({ id, name: id, 'aria-invalid': !!err[id], 'aria-describedby': err[id] ? `${id}-err` : undefined })
  const Sel = ({ id, label, opts }: { id: string; label: string; opts: string[] }) =>
    <Fld id={id} label={label}><select {...p(id)} className="field">{opts.map(o => <option key={o}>{o}</option>)}</select></Fld>
  return (
    <form name="property-inquiry" onSubmit={submit} noValidate className="grid gap-5 border border-line bg-card p-6 md:p-10" data-netlify="true" netlify-honeypot="bot-field">
      <input type="hidden" name="form-name" value="property-inquiry" />
      <p hidden><label>Do not fill this in <input name="bot-field" /></label></p>
      <div role="group" aria-label="Inquiry type" className="grid grid-cols-2 gap-2">
        {(['sell', 'buy'] as Intent[]).map(i => <button type="button" key={i} aria-pressed={intent === i} onClick={() => setIntent(i)}
          className={`min-h-[48px] border px-3 text-sm font-semibold transition-colors ${intent === i ? 'border-gold bg-gold text-bg' : 'border-line text-mute hover:border-gold'}`}>{i === 'sell' ? 'I want to sell a property' : 'I want to buy a property'}</button>)}
      </div>
      <Fld id="fullName" label="Full name *"><input {...p('fullName')} autoComplete="name" className="field" /></Fld>
      <div className="grid gap-5 sm:grid-cols-2">
        <Fld id="phone" label="Phone number *"><input {...p('phone')} type="tel" autoComplete="tel" className="field" /></Fld>
        <Fld id="whatsapp" label="WhatsApp number (if different)"><input {...p('whatsapp')} type="tel" className="field" /></Fld>
        <Fld id="email" label="Email address (optional)"><input {...p('email')} type="email" autoComplete="email" className="field" /></Fld>
        <Sel id="contactMethod" label="Preferred contact method" opts={methods} />
      </div>
      <Fld id="location" label={sell ? 'Property location / area *' : 'Preferred location / area *'}><input {...p('location')} className="field" placeholder="For example: DHA Phase 5, Lahore" /></Fld>
      <div className="grid gap-5 sm:grid-cols-2">
        <Sel id="propertyType" label="Property type" opts={types} />
        {sell ? <Fld id="askingPrice" label="Approximate asking price (optional)"><input {...p('askingPrice')} className="field" /></Fld>
          : <Fld id="budget" label="Budget range"><input {...p('budget')} className="field" placeholder="For example: PKR 1 to 1.5 crore" /></Fld>}
        {sell ? <Fld id="size" label="Property size (optional)"><input {...p('size')} className="field" placeholder="For example: 10 marla" /></Fld>
          : <Sel id="purpose" label="Purpose" opts={purposes} />}
        {!sell && <Fld id="size" label="Preferred property size (optional)"><input {...p('size')} className="field" /></Fld>}
        {sell && <Sel id="hasMedia" label="Do you have property photos or videos?" opts={['Yes', 'No']} />}
      </div>
      {sell ? <Fld id="description" label="Property description (optional)"><textarea {...p('description')} rows={3} className="field" /></Fld>
        : <Fld id="requirements" label="Additional requirements"><textarea {...p('requirements')} rows={3} className="field" /></Fld>}
      <Fld id="notes" label="Additional notes"><textarea {...p('notes')} rows={2} className="field" /></Fld>
      <div>
        <label className="flex items-start gap-3 text-sm text-mute"><input {...p('consent')} type="checkbox" className="mt-1 h-5 w-5 accent-[#C6A76A]" />
          <span>I agree to be contacted about my inquiry and have read the <a href="#privacy" className="text-gold underline">privacy notice</a>. *</span></label>
        {err.consent && <p id="consent-err" role="alert" className="mt-1 text-sm text-red-400">{err.consent}</p>}
      </div>
      {status === 'error' && <p role="alert" className="border border-red-400 p-3 text-sm text-red-300">Your inquiry was not sent. Please check your connection and try again, or contact us on WhatsApp. Forms only work on the deployed Netlify site.</p>}
      <button className="btn btn-gold w-full" disabled={status === 'loading'}>
        {status === 'loading' ? <><Loader2 size={16} className="animate-spin" />Sending</> : sell ? 'Submit My Property' : 'Find My Property Options'}</button>
    </form>)
}
