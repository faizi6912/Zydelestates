export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: { extend: {
    colors: { bg: '#0B0B0B', bg2: '#141414', card: '#191919', ivory: '#F7F5F0', mute: '#B8B5AE', gold: '#C6A76A', gold2: '#D8BC87', line: '#33312D' },
    fontFamily: { display: ['"Playfair Display"', 'Georgia', 'serif'], sans: ['Inter', 'system-ui', 'sans-serif'] }
  } }, plugins: []
}
