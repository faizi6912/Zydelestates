# Zydel Estates landing page

React + Vite + TypeScript + Tailwind. Works on Windows. Hosted on Netlify.

## Run it
1. Install Node.js 18+ (nodejs.org). 2. Open this folder in a terminal (on Windows: right-click > Open in Terminal).
3. `npm install`  4. `npm run dev` and open the address shown.  5. `npm run build` makes the production site in `dist`. `npm run preview` shows it.

## Update details (one file)
Edit `src/config/site.ts`: WhatsApp (digits only with country code, e.g. 923001234567), phone, email, Instagram and Facebook URLs, address, service areas, commission wording. Anything left as '' is hidden, and the WhatsApp buttons (including the floating one) only appear once a number is set.
Also replace `YOUR-DOMAIN.com` in `public/robots.txt` and `public/sitemap.xml`, and write your full privacy policy in the Privacy section of `src/App.tsx`.

## Images
The hero uses a line-art SVG and the "How we present properties" section uses clearly labelled sample placeholders. Add your own photos in `public/` (compressed WebP, under about 200 KB) and use `<img loading="lazy" alt="...">`. Do not present sample visuals as completed client work.

## Netlify Forms (lead submissions)
1. Deploy to Netlify (below). Forms are detected at build time from the hidden form in `index.html`.
2. Netlify dashboard > your site > Forms. Confirm `property-inquiry` is listed. If not, redeploy.
3. Forms > Form notifications > add an email notification so you are alerted to each lead.
4. Test: open the live site, submit a seller inquiry and a buyer inquiry, check both appear under Forms > Submissions. Forms do NOT work on `npm run dev`; an error message is shown there by design.

## Deploy
Push to GitHub > Netlify > Add new site > Import from Git. Build command `npm run build`, publish directory `dist` (set in `netlify.toml`).

## You must supply
WhatsApp number, phone, email, social URLs, address, real photos, privacy policy text, domain, notification email.
